<?php

namespace App\Policies;

use App\Models\PropertyEvaluation;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class PropertyEvaluationPolicy
{
    use HandlesAuthorization;

    /**
     * Se você quiser que o "super admin" salte todas as checagens:
     */
    public function before(User $user, $ability)
    {
        if ($user->profile_id === User::PROFILE_ADMIN) {
            return true;
        }
    }

    /**
     * View any evaluations (listagem)
     */
    public function viewAny(User $user)
    {
        return in_array($user->profile_id, [
            User::PROFILE_ADMIN,
            User::PROFILE_MANAGER,
            User::PROFILE_VIEWER,
        ]);
    }

    /**
     * View one evaluation
     */
    public function view(User $user, PropertyEvaluation $evaluation)
    {
        // Verifica se o usuário tem permissão para ver a propriedade relacionada
        return $user->id === $evaluation->property->owner_id
            || $user->profile_id === User::PROFILE_ADMIN
            || $user->profile_id === User::PROFILE_MANAGER
            || $user->profile_id === User::PROFILE_VIEWER;
    }

    /**
     * Criar evaluation
     */
    public function create(User $user)
    {
        return in_array($user->profile_id, [
            User::PROFILE_ADMIN,
            User::PROFILE_MANAGER,
        ]);
    }

    /**
     * Atualizar uma evaluation
     */
    public function update(User $user, PropertyEvaluation $evaluation)
    {
        // Apenas o criador da avaliação ou um admin/manager pode atualizar
        return $user->id === $evaluation->user_id
            || $user->profile_id === User::PROFILE_ADMIN
            || $user->profile_id === User::PROFILE_MANAGER;
    }

    /**
     * Deletar uma evaluation
     */
    public function delete(User $user, PropertyEvaluation $evaluation)
    {
        // Apenas o criador da avaliação ou um admin pode deletar
        return $user->id === $evaluation->user_id
            || $user->profile_id === User::PROFILE_ADMIN;
    }
}